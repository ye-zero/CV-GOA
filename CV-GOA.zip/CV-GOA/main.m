

% You can simply define your cost in a seperate file and load its handle to fobj 
% The initial parameters that you need are:
%__________________________________________
% fobj = @YourCostFunction
% dim = number of your variables
% Max_iteration = maximum number of generations
% SearchAgents_no = number of search agents
% lb=[lb1;lb2;...;lbn] where lbn is the lower bound of variable n 
% ub=[ub1;ub2;...;ubn] where ubn is the upper bound of variable n
% If all the variables have equal lower bound you can just
% define lb and ub as two single number numbers

% To run GOA: [Best_score,Best_pos,GOA_cg_curve]=GOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj)
%__________________________________________

clear all %�������
clc %�����Ļ

SearchAgents_no=50; % Number of search agents

Function_name='F1'; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper)

runTime=1;

Max_iteration=100; % Maximum numbef of iterations

globalbest=ones(runTime,1);%ÿ�����е�����ֵ


for i=1:runTime

% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_details(Function_name); %fobj��������

% v=zeros(N,dim);  %�ٶ�		
% vmax=0.5;  %�ٶ����ֵ
% vmin=-0.5;  %�ٶ���Сֵ
% for ii=1:N    
%     for jj=1:dim
%         v(ii,jj)=(rand(1)+vmin/(vmax-vmin))*(vmax-vmin);   %����vmin��vmax�������
%     end
% end



[Target_score,Target_pos,GOA_cg_curve, Trajectories,fitness_history, position_history]=GOA(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);






% figure('Position',[454   445   894   297])
% %Draw search space
% subplot(1,3,1);
% func_plot(Function_name);
% title('Parameter space')
% xlabel('x_1');
% ylabel('x_2');
% zlabel([Function_name,'( x_1 , x_2 )'])
% box on
% axis tight

% subplot(1,5,2);
% hold on
% for k1 = 1: size(position_history,1)
%     for k2 = 1: size(position_history,2)
%         plot(position_history(k1,k2,1),position_history(k1,k2,2),'.','markersize',1,'MarkerEdgeColor','k','markerfacecolor','k');
%     end
% end
% plot(Target_pos(1),Target_pos(2),'.','markersize',10,'MarkerEdgeColor','r','markerfacecolor','r');
% title('Search history (x1 and x2 only)')
% xlabel('x1')
% ylabel('x2')
% box on
% axis tight

% subplot(1,3,2);
% hold on
% plot(Trajectories(1,:));
% title('Trajectory of first grasshopper')
% xlabel('Iteration')
% box on
% axis tight

% subplot(1,4,3);
% hold on
% plot(mean(fitness_history));
% title('Mean of all grasshoppers')
% xlabel('Iteration')
% box on
% axis tight

%Draw objective space
% subplot(1,3,3);
% semilogy(GOA_cg_curve,'Color','r')
% title('Convergence curve')
% xlabel('Iteration');
% ylabel('The function value');
% box on
% axis tight
% set(gcf, 'position' , [39         479        1727         267]);
% 
% 
% globalbest(i,1)=Target_score;
%  subplot(1,3,3);
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% G=[1e5,1e3,1e2,50,10,2,8e-1,2e-1,9e-2,5e-2,1e-2];
% 
% O=[1e5,1e2,10,8e-1,5e-1,1e-1,7e-2,4e-2,2e-2,5e-3];
% 
% C=[1e5,5e-3,5e-4,8e-5,5e-5,3e-5,2e-5,1e-6,1e-10];
% 
% 
% y=[0,10,15,20,30,40,50,60,70,80,100];
% y1=[0,10,15,25,35,55,65,75,85,100];
% y2=[0,10,15,25,35,55,60,70,90];
% 
%   
% % figure1=figure('Color',[1 1 1]);  
%   
% semilogy(y, G, 'r-o', ...  
%     y1, O, 'b-v', ...  
%     y2, C,'black ','Markersize', 5,'linewidth',2); 
% 
%  
%   
% xlabel('Iteration');  
% ylabel('The best function values');  
% xlim([0, 100]);  
% ylim([1e-10, 1e5]); 
%   
% 
% 
% set(gca, 'XTick',[0,20,40,60,80,100]); 
% 
% set(gca, 'YTick',[1e-10,1e-5,1,1e5]); 
% 
% legend1=legend('GOA','OBLGOA','CV-GOA','location','Best');
% set(legend1,'FontSize',12);  
% set(legend1,'box','on');  











display(['The best solution obtained by GOA is : ', num2str(Target_pos)]); %����ֵת�����ַ����� ת�������ʹ��fprintf��disp�����������
display(['The best optimal value of the objective funciton found by GOA is : ', num2str(Target_score)]);
end
fprintf('Globalbest=%g��worst=%g, median=%g, Average=%g,Std=%g',min(globalbest(:)),max(globalbest(:)),median(globalbest(:)),mean(globalbest(:)),std(globalbest(:)));